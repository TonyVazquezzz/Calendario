<?php

$Correo=$_POST['Correo'];
$Contrasena=$_POST['Contrasena'];


//Conexion
//$contrasena1=password_verify($Contrasena,$Contrasena)
$conn=mysqli_connect("localhost","root","","usuariosreg");
$consulta="SELECT * FROM usu WHERE Correo='$Correo' and Contrasena='$contrasena'";
$rel=mysqli_query($conn,$consulta);

$fi= mysqli_num_rows($rel);
if ($fi>0){
  header("location:index.html");
}
else{
  header("location: ingresar.html?fallo=true");

}

mysqli_free_result($rel);
mysqli_close($conn);

?>
